# TweetGen

Made by Aditya Bhandare.

AI agent that researches a topic and writes 3 ready-to-post tweets. Runs on Groq with Tavily web research, hosted on Vercel.

## Files
- index.html: the main TweetGen app
- pricing.html: Pro plans and access-code unlock
- api/generate.js: the agent, free limit and Pro codes (Vercel serverless function)

## Vercel environment variables
- GROQ_API_KEY (required): console.groq.com
- TAVILY_API_KEY (optional, live research): app.tavily.com
- PRO_CODES (optional): comma-separated access codes for paying users, e.g. TG-AB12X,TG-KP93M
- FREE_GENERATIONS (optional, default 2), QUOTA_RESET_DAYS (default 30), DAILY_SITE_CAP (default 200), PRO_DAILY_LIMIT (default 50)
- UPSTASH_REDIS_REST_URL and UPSTASH_REDIS_REST_TOKEN (optional, makes limits stick on Vercel)

## Payments
In pricing.html, paste your Razorpay Payment Page links into PAYMENT_LINKS and your email into CONTACT_EMAIL.
